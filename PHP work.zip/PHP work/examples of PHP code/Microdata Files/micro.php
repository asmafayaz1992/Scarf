<?php 
$servername = "mysql5"; 
$username = "fet12014211"; 
$password = "Milkshake12"; 
$dbname = "fet12014211";  



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT *
FROM champion, country, year, country_has_champion
WHERE 
    id_champion = country_has_champion.champion_id_champion AND
    id_country = country_has_champion.country_id_country AND
    id_champion = year.champion_id_champion";

$result = $conn->query($sql); 

echo '<h2>Chess World Champions (1886 to 2013)</h2>'; 
echo '<table border = "1"><tr><th>Name</th><th>Years</th><th>Country</tr></th>'; 


$id=''; 
if ($result->num_rows > 0) { 

$fname1=NULL;
	$syear1=NULL;
	$eyear1=NULL;
	
	
	while($row = $result->fetch_assoc()) { 
		
		
		$fn = $row["fname"];
		$yrs = $row["syear"]."-".$row["eyear"];
		$cnt = $row["name"];
		
		echo "<tr>";
		if ($fname1 != $row["fname"]) {
			echo "<td><div itemsope itemtype='http://schema.org/Person'><a itemprop='url' href='". $row["playerlink"]."'>".$fn."</a></div></td>";
		}
		else {
			echo "<td/>";
		}
		if ($syear1 != $row["syear"]) {
			echo "<td><div itemsope itemtype='http://schema.org/Text'><span itemprop='duration'>$yrs ".$row["notes"]."</div></td>";
		}	
		else {
			echo "<td/>";
		}	
		echo "<td><div itemscope itemtype='imageObject'><img itemprop='image' src='".$row["flag"]."'width=30px><a itemprop='url' href='". $row["wikilink"]."'>".$cnt."</a></div></td>";
		echo "</tr>";
		
		
		$fname1 = $row["fname"];
		$syear1 = $row["syear"];
		$eyear1 = $row["eyear"];
		
	}
} 
echo '</table>';
$conn->close();
?>










 

