<?php
$servername = "mysql5";
$username = "fet12014211";
$password = "Milkshake12";
$dbname = "fet12014211";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT *
FROM champion
LEFT JOIN country_has_champion
ON champion.id_champion=country_has_champion.champion_id_champion
LEFT JOIN country
ON country_has_champion.country_id_country=country.id_country
LEFT JOIN year
ON champion.id_champion=year.champion_id_champion
";

$result = $conn->query($sql); 


echo '<h2>Chess World Champions (1886 to 2013)</h2>'; 
echo '<table border="1"><tr><th>Name</th><th>Years</th><th>Country</th></tr>'; 

if ($result->num_rows > 0) { 
    
	$fname1=NULL;
	$syear1=NULL;
	$eyear1=NULL;
	
	
	while($row = $result->fetch_assoc()) { 
		
		
		$fn = $row["fname"];
		$yrs = $row["syear"]."-".$row["eyear"];
		$cnt = $row["name"];
		
		echo "<tr>";
		if ($fname1 != $row["fname"]) {
			echo "<td><a href='".$row["playerlink"]."'>".$fn."</a></td>";
		}
		else {
			echo "<td/>";
		}
		if ($syear1 != $row["syear"]) {
			echo "<td>$yrs ".$row["notes"]."</td>";
		}	
		else {
			echo "<td/>";
		}	
		echo "<td><img src='".$row["flag"]."'width=30px><a href='".$row["wikilink"]."'>".$cnt."</a></td>";
		
		echo "</tr>";
		
		
		$fname1 = $row["fname"];
		$syear1 = $row["syear"];
		$eyear1 = $row["eyear"];
		
	}
} 
echo '</table>';
$conn->close();
?>