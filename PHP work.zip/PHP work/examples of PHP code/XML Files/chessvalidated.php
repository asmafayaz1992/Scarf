<?php

$servername = "mysql5";
$username = "fet12014211";
$password = "Milkshake12";

// Create connection
$conn = new mysqli($servername, $username, $password);


$xdoc = new DomDocument;
$xmlfile = 'chess.xml';
$xmlschema = 'chess.xsd';
//Load the xml document in the DOMDocument object
$xdoc->Load($xmlfile);
//Validate the XML file against the schema
if ($xdoc->schemaValidate($xmlschema)) {
print "$xmlfile is valid.\n";
} else {
print "$xmlfile is invalid.\n";
}
?>