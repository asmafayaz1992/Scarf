<?php 


$servername = "mysql5"; 
$username = "fet12014211"; 
$password = "Milkshake12"; 
$dbname = "fet12014211"; 

// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 
// Check connection 
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
}  


$sql = "SELECT * FROM player a 
LEFT JOIN player_has_country b ON a.idPlayer=b.player_idPlayer 
LEFT JOIN country c ON c.idCountry=b.country_idCountry 
LIMIT 27"; 


$result = $conn->query($sql); 

echo '<h2>Chess World Champions (1886 to 2013)</h2>';  
echo '<table border = "1"><tr><th>Name</th><th>Years</th><th>Country</tr></th> 
<div itemscope itemtype="http://schema.org/Event">'; 

$id=''; 
if ($result->num_rows > 0) { 
    // output data of each row 
    while($row = $result->fetch_assoc()) { 
     
    if ($id != $row["playerName"] || $id == '') { 
        if ($id != ''){ 
        echo "</td></tr>";} 
     
        echo "<tr><td><div itemscope itemtype='http://schema.org/Thing'><a itemprop='sameAs' href='". $row["wikilink"]."'>". "<div itemscope itemtype='http://schema.org/Person'>"."<span itemprop='name'>". $row["fname"]. "</div></a></td> <td> <div itemscope itemtype='http://schema.org/MediaObject'><span itemprop='duration'> "  .$row["yearsOne"] .$row["notes"]."<br>".$row["yearsTwo"]. $row["notes2"]."<br>".$row["yearsThree"] . "</div>"."</td><td>"; 
        echo "<div itemscope itemtype='http://schema.org/PostalAddress'><img itemprop='image' src='".$row["flag"]."' width=30px>". "<a itemprop='url' href='" . $row["name"]."'>" . "<span itemprop='addressCountry'>" . $row["wikilink"]."<br>";} 
     
    else{ 
        echo "<div itemscope itemtype='http://schema.org/PostalAddress'><img itemprop='image' src='".$row["flag"]."'width=30px>" . "<a itemprop='url' href='". $row["name"]."'>" . "<span itemprop='addressCountry'>" . $row["wikilink"]."<br>";} 
         

        $id = $row["playerName"]; 
    } 
     
} else { 
    echo "0 results"; 
}     
echo '</div></table>'; 

$conn->close(); 
?> 
