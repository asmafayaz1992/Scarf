<?php


$servername = "mysql5"; 
$username = "fet12014211"; 
$password = "Milkshake12"; 
$dbname = "fet12014211"; 

// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 


$xdoc = new DomDocument;
$xmlfile = 'chessc.xml';
$xmlschema = 'chessc.xsd';
//Load the xml document in the DOMDocument object
$xdoc->Load($xmlfile);
//Validate the XML file against the schema
if ($xdoc->schemaValidate($xmlschema)) {
print "$xmlfile is valid.\n";
} else {
print "$xmlfile is invalid.\n";
}
?>