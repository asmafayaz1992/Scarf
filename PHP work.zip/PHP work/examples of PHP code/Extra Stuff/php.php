<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: collapse;
}

table, td, th, tbody {
    border: 1px solid black;
height: 100p%;

}
tbody 
{

}

td 
{
list-style-type:none;
}

li{
position: relative;
}

p {

}
 img {
width: 30px;
height: 20px;
margin-right: 5px;
 }
 
 h4 {
 text-align: center;
 
 }
 h3{
 postion: relative;
 top: 10px;

 }
 
 a {
margin-right: 4px;
 }
 
 
</style>
<title>PHP Script</title>
</style>
</head>
</html>
<?php
$servername = "mysql5";
$username = "fet12014211";
$password = "Milkshake12";
$dbname = "fet12014211";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "SELECT * 
FROM  country, country_has_champion, country, year
WHERE
   id_country=country_id_country AND
   id_champion=country_has_champion.champion_id_champion AND
   id_champion=year.champion_id_champion

LIMIT 42";

$result = $conn->query($sql); 


echo '<h2>Chess World Champions (1886 to 2013)</h2>'; 
echo '<table border = "1"><tr><th>Name</th><th>Years</th><th>Country</tr></th>'; 

$id=''; 
if ($result->num_rows > 0) { 
    while($row = $result->fetch_assoc()) { 
     
    if ($id != $row["fname"] || $id == '') { 
        if ($id != ''){ 
        echo "</td></tr>";} 
     
        echo "<tr><td><a href='". $row["wikilink"]."'>'". $row["fname"]. "</a></td><td>'" .$row["syear"] .$row["eyear"]. $row["notes"]. $row["syear"] .$row["eyear"]. $row["notes"]. $row["syear"]."<br>".$row["eyear"] . $row["notes"] ."<br>.</div>"."</td><td>"; 
        echo "<img src='".$row["flag"]."' width=30px>". "<a href='". $row["wikilink"]."'>" . $row["name"]."<br>";} 
         

        $id = $row["fname"]; 
    } 
} else {
    echo "16 results";
	echo '</table>';
} 
$conn->close();
?>