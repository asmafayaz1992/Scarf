<?php 

/*define('DB_NAME','fet12014211');
define('DB_USER','fet12014211');
define('DB_PASS','Milkshake12');
define('DB_HOST','mysql5');        //replace localhost with hostname ********

$link = mysql_connect(DB_HOST,DB_USER,DB_PASS);

if (!$link) {
    dir('There was a problem when trying to connect to the host. Please contact Tech Support. Error: ' . mysql_error());    
}

$db_selected = mysql_select_db(DB_NAME, $link);

if (!$link) {
    dir('There was a problem when trying to connect to the database. Please contact Tech Support. Error: ' . mysql_error());    
}

header('Content-type:text/html; charset=utf-8');
require('simple_html_dom.php');

// Create DOM from URL or file
$html = file_get_html('http://www.cems.uwe.ac.uk/~p-chatterjee/2014-15/modules/atwd1/assignment/chess_world_champions.html');

//$html;*/


//Helped in PAL Espresso Programming with this bit	


/*foreach(array_slice($html->find('tr'),1) as $tr){
 $error = FALSE;
		$data = $tr->find('td');
		$fname = $data[0]->plaintext;
		$link = $data[0]->find('a');
		$wikilink = $link[0]->href;
	    $sql = "INSERT * INTO champion (fname,wikilink) VALUES ('$fname', '$wikilink')"; 
		$result = mysql_query($sql);
		$id = mysql_insert_id();
		echo $data[1]->plaintext;
		
		$country = $data[0]->find('a');
		$cname = $country[0]->plaintext;
		$clink = $country[0]->href;
		$flag = $data[2]->find('img');
		$img = $flag[0]->src;
		$countryid = mysql_insert_id();
		
		$sql = "INSERT INTO country_has_champion (country_id_country,champion_id_champion) VALUES ($countryid,$id)"; 
		$result = mysql_query($sql);
		
		if(isset($country[1])){
			$cname = $country[1]->plaintext;
			$clink = $country[1]->href;
			
			$sql = "INSERT INTO country (cname, wikilink, flag) VALUES ('$cname', '$clink', '$flag')"; 
			$result = mysql_query($sql);
			$countryid = mysql_insert_id();
			$sql = "INSERT INTO country_has_champion (country_id_country,champion_id_champion) VALUES ($countryid,$id)"; 
			$result = mysql_query($sql);
		}
		
		if(isset($country[2])){
			$cname = $country[2]->plaintext;
			$clink = $country[2]->href;
			
			$sql = "INSERT INTO country (cname, link, flag) VALUES ('$cname', '$clink', '$flag')"; 
			$result = mysql_query($sql);
			$countryid = mysql_insert_id();
			$sql = "INSERT INTO country_has_champion (country_id_country,champion_id_champion) VALUES ($countryid,$id)"; 
		    $result = mysql_query($sql);
		}
		
		
			
		
 $year = $data[0]->find('a');
     $syear = $data[0]->plaintext;
	 $eyear = $data[0]->plaintext;
	 $notes = $data[0]->plaintext;
	 $yearid = mysql_insert_id();
	 $result = mysql_query($sql);	
	 $sql = "INSERT INTO country (syear,eyear,notes) VALUES ('$syear', '$eyear', '$notes')"; 
		
if(isset($year[1])){
			
     $syear = $data[1]->plaintext;
	 $eyear = $data[1]->plaintext;
			
			 $sql = "INSERT INTO country (syear,eyear,notes) VALUES ('$syear', '$eyear', '$notes')"; 	
			$result = mysql_query($sql);
			$yearid = mysql_insert_id();
			$sql = "INSERT INTO country_has_champion (country_id_country,champion_id_champion) VALUES ($countryid,$id)"; 
		    $result = mysql_query($sql);
		}
	if(isset($year[2])){
			
     $syear = $data[2]->plaintext;
	 $eyear = $data[2]->plaintext;
			
			 $sql = "INSERT INTO country (syear,eyear,notes) VALUES ('$syear', '$eyear', '$notes')"; 	
			$result = mysql_query($sql);
			$yearid = mysql_insert_id();
			$sql = "INSERT INTO country_has_champion (country_id_country,champion_id_champion) VALUES ($countryid,$id)"; 
		    $result = mysql_query($sql);
			}
			
			if($error == TRUE){ 
            echo 'Data already inserted <br>'; 
        }else{ 
            echo 'Data successfully inserted! <br>'; 
        } 
 
			}

?> 